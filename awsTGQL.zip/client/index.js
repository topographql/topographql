import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.js';
//import ApolloClient from 'apollo-boost';
import './styles/styles.scss';

ReactDOM.render(<App />, document.getElementById('root'));

